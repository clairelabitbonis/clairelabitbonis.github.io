+++
title = "Perception 3D #2 : Localisation monoculaire"
subtitle = "Estimation par itérations successives des paramètres extrinsèques d'une caméra."

date = 2016-04-20T00:00:00
lastmod = 2019-02-13T00:00:00
draft = true
math = true
highlight = true
highlight_languages = "matlab"
comments = true

# Authors. Comma separated list, e.g. `["Bob Smith", "David Jones"]`.
authors = ["Claire Labit-Bonis"]

tags = ["teaching", "perception"]
summary = "Estimation par itérations successives des paramètres extrinsèques d'une caméra."

# Featured image
# To use, add an image named `featured.jpg/png` to your project's folder. 
[image]
  # Caption (optional)
  # caption = "Image credit: [**Unsplash**](https://unsplash.com/photos/CpkOjOcXdUY)"

  # Focal point (optional)
  # Options: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight
  focal_point = ""

  # Show image only in page previews?
  preview_only = true
  
#TODO: expliquer dmatPos*matPos, lambda, détailler le calcul de matrice intrinsic inverse et stockage des segments 
#l1-l2. Pourquoi ne pas utiliser Ni.(P2i-P1i) plutôt que Ni.P1i + Ni.P2i ?
#Developpement de Taylor ordre 1 pour F(X) courant : tangente à la fonction en ce nouveau point.
# Transpoint, changer les noms des variables : P_i => P, P_f => P_transformed ?
# Modifier les matrices modA, App3d, [0,1,2], [0,3,5] etc.
# Pourquoi err/2N ? Moyenne?
+++
{{% alert note %}}
Cet exercice consiste à remplir cinq fonctions vides dans le fichier `localisation.py` : [`perspective_projection
`, `transform_and_draw_model`](#anchor-step-1), `calculate_error`, `partial_derivatives` et `calculate_normal_vector
`. Chaque
 fonction et le rôle qu'elle remplit sont décrits dans cet article.
{{% /alert %}}

L'objectif de cet exercice est de trouver la transformation optimale à
appliquer à un modèle 3D exprimé en centimètres dans un repère *objet*
$\mathcal{R\_o} (X,Y,Z)$ (parfois appelé repère *monde*
$\mathcal{R\_m}$) afin de le dessiner dans une image 2D exprimée en
pixels dans un repère *image* $\mathcal{R\_i} (u,v)$. Par
"transformation", on entend une rotation et une translation de la scène
sur les axes $x$, $y$ et $z$ des points dans $\mathcal{R\_o}$.


Dans notre cas, on veut *mapper* un modèle virtuel de parallélépipède
rectangle (une boite) sur une boite réelle capturée par une caméra. La
première figure représente le modèle virtuel, la deuxième illustre
l'objectif à atteindre.

![Modèle 3D de l'objet](images/modele_3d.png "Modèle 3D de l'objet")
![Modèle 3D projeté dans l'image](images/modele_projete_image.png "Modèle 3D projeté dans l'image")

**Paramètres intrinsèques.** 
On utilise le modèle de caméra sténopé qui permet de réaliser cette opération en deux transformations successives : $\mathcal{R\_o} \rightarrow \mathcal{R\_c}$ puis $\mathcal{R\_c} \rightarrow \mathcal{R\_i}$. En plus des repères $\mathcal{R\_o}$ et $\mathcal{R\_i}$, il faut donc aussi considérer le repère caméra $\mathcal{R\_c}$.

{{% alert note %}}
La ressource *[Modélisation et calibrage d'une caméra](http://www.optique-ingenieur.org/fr/cours/OPI_fr_M04_C01/co/Grain_OPI_fr_M04_C01_2.html)* décrit en détail le modèle sténopé et peut aider à la compréhension de l'exercice.
{{% /alert %}}

![Changements de repères](images/goal.png "Changements de repères")

> Wikipédia définit le [modèle sténopé](https://en.wikipedia.org/wiki/Pinhole_camera_model) comme décrivant *la relation mathématique entre les coordonnées d'un point dans un espace en trois dimensions et sa projection dans le plan image d'une caméra sténopé i.e. une caméra dont l'ouverture est décrite comme un point et qui n'utilise pas de lentille pour focaliser la lumière*. 

Le passage entre le repère $\mathcal{R\_c}$ et $\mathcal{R\_i}$ se fait à l'aide des paramètres **intrinsèques** de la caméra. Ces coefficients $(\alpha\_u, \alpha\_v, u\_0, v\_0)$ sont ensuite stockés dans une matrice de passage homogène $K\_{i \leftarrow c}$ de sorte que l'on peut décrire la relation $p\_i = K\_{i \leftarrow c}.P\_c$ comme étant :

$$s.\begin{bmatrix}u\\\\v\\\\1\end{bmatrix}\_{\mathcal{R}\_i} = \begin{bmatrix}\alpha\_u & 0 & u\_0 & 0\\\\0 & \alpha
\_v & v\_0 & 0\\\\0 & 0 & 1 & 0\end{bmatrix} . \begin{bmatrix}X\\\\Y\\\\Z\\\\1\end{bmatrix}\_{\mathcal{R
}\_c}$$

avec :

- $p\_i$ (à gauche) le point exprimé en pixels dans le repère 2D image $\mathcal{R\_i}$,
- $P\_c$ (à droite) le point exprimé en centimètres dans le repère 3D caméra $\mathcal{R\_c}$,
- $s = \frac{1}{Z}$,
- $\alpha_u = k_x f$, $\alpha_v = k_y f$ :
    - $k_x = k_y$ le nombre de pixels par millimètre du capteur dans les directions $x$ et $y$ -- l'égalité n'étant
 vraie que si les pixels sont carrés,
    - $f$ la distance focale.
- $u_0$ et $v_0$ les centres de l'image en pixels dans $\mathcal{R}_i$.


Dans notre cas, ces coefficients sont connus *a priori* (et généralement donnés par le fournisseur de la caméra), avec $\alpha\_u = 529.654$, $\alpha\_v = 527.635$, $u\_0 = 310.740$ et $v\_0 = 217.256$.

**Paramètres extrinsèques.**
Pour atteindre notre objectif de départ, c'est-à-dire afficher dans l'image en pixels notre modèle 3D virtuel, nous devons estimer les coefficients de la transformation $\mathcal{R\_o}\rightarrow\mathcal{R\_c}$ permettant d'établir la relation $P\_c=M\_{c\leftarrow o}.P\_o$, avec : 

- $M\_{c\leftarrow o}=\big[ R\_{\alpha\beta\gamma} | T \big]$ la matrice de transformation homogène composée des angles d'Euler et de la translation selon les axes $x$, $y$ et $z$ du repère. 

- $R\_{\alpha\beta\gamma}$ la matrice de rotation résultat de l'application successive (et donc de la multiplication 
entre elles) des matrices de rotation $R\_\gamma$, $R\_\beta$ et $R\_\alpha$ :

$$R\_\alpha = \begin{bmatrix}1 & 0 & 0\\\\0 & \cos \alpha & -\sin \alpha\\\\0 & \sin \alpha & \cos \alpha\end{bmatrix}$$

$$R\_\beta = \begin{bmatrix}\cos \beta & 0 & -\sin \beta\\\\0 & 1 & 0\\\\\sin \beta & 0 & \cos \beta\end{bmatrix}$$

$$R\_\gamma = \begin{bmatrix}\cos \gamma & -\sin \gamma & 0\\\\\sin \gamma & \cos \gamma & 0\\\\0 & 0 & 1\end{bmatrix}$$

Avec les bons paramètres extrinsèques $(\alpha, \beta, \gamma, t\_x, t\_y, t\_z)$, le modèle 3D dans son repère $\mathcal{R\_o}$ pourra être transformé jusqu'à être exprimé dans $\mathcal{R\_c}$ puis dans $\mathcal{R\_i}$, en respectant la relation suivante pour chaque point $P^o$ :

$$ p\_i = K\_{i \leftarrow c} M\_{c\leftarrow o} P\_o$$

$$s.\begin{bmatrix}u\\\\v\\\\1\end{bmatrix}\_{\mathcal{R}\_i} = \begin{bmatrix}\alpha\_u & 0 & u\_0 & 0\\\\0 & \alpha
\_v & v\_0 & 0\\\\0 & 0 & 1 & 0\end{bmatrix} . \begin{bmatrix}r\_{11} & r\_{12} & r\_{13} & t\_x\\\\r\_{21} & r\_{22} & r\_{23} & t\_y\\\\r\_{31} & r\_{32} & r\_{33} & t\_z\\\\0 & 0 & 0 & 1\end{bmatrix} . \begin{bmatrix}X\\\\Y\\\\Z\\\\1\end{bmatrix}\_{\mathcal{R}\_o}$$

> Les paramètres intrinsèques sont connus ; pour trouver les paramètres extrinsèques on peut mettre en oeuvre une méthode de localisation (*i.e.* d'estimation des paramètres) dite *par recalages successifs*.

**Estimation des paramètres extrinsèques.**

On démarre d'une estimation initiale grossière des paramètres $(\alpha, \beta, \gamma, t\_x, t\_y, t\_z)$. Cette estimation initiale est plus ou moins juste en fonction de la connaissance que l'on a *a priori* de la scène, de l'objet, de la position de la caméra.

Dans notre cas, les paramètres initiaux ont pour valeurs $\alpha = -2.1$, $\beta = 0.7$, $\gamma = 2.7$, $t\_x = 151
.6$, $t\_y = 46.8$ et $t\_z = 2164.8$, c'est-à-dire que l'on sait avant même de commencer que le modèle 3D devra
 subir une rotation d'angles $(-2.1, 0.7, 2.7)$ autour de ses trois axes, et qu'il devra se décaler d'environ $150cm$
 en $x$, $46cm$ en $y$ et $2164cm$ en $z$. 
 
{{% alert note %}}
Cette connaissance *a priori* de la scène vient du fait que l'on est
  capable, en tant qu'humain, d'évaluer la distance de l'objet réel par rapport au capteur seulement en regardant l'image. 
  
  **Animation à venir**.
{{% /alert %}}

#### Etape 1 : afficher le modèle dans $\mathcal{R_i}$ {#anchor-step-1}

Pour visualiser le modèle 3D dans l'image 2D et se faire une idée de la justesse de notre estimation, il est n
écessaire de coder la fonction `tranform_and_draw_model` qui applique les transformations successives aux points
 exprimés dans $
\mathcal{R_o}$ et affiche le résultat dans l'image.

Dans le code Python fourni, les points du modèle sont stockés dans `model3d_Ro`, la matrice de transformation $M\_{c
\leftarrow o}$ est stockée dans `extrinsic_matrix` et les paramètres intrinsèques de la caméra de gauche (ou caméra n°1) sont
 stockés dans `intrinsic_left_matrix`.

{{% alert note %}}
On utilise un système avec deux caméras, mais pour l'instant nous ne nous intéressons qu'à la première, celle de gauche.
{{% /alert %}}

Au lancement du programme `localisation.py`, deux figures s'ouvrent : l'une représente l'image de la boite capturée
 par la caméra, l'autre représente le modèle virtuel à transformer. Il faut dans un premier temps sélectionner cinq arêtes appartenant à la boite sur la première figure (par *click* souris sur les coins), puis sélectionner dans le même ordre les arêtes correspondantes sur le modèle.

![Sélection des arêtes dans l'image](images/edges_img.png)
![Sélection des arêtes correspondantes sur le modèle](images/edges_model.png)

De cette manière, on pourra avoir une idée de l'erreur commise sur l'estimation des paramètres extrinsèques en comparant la distance entre les arêtes sélectionnées dans l'image et celles du modèle projeté (ce critère d'optimisation est décrit un peu plus tard).

La deuxième étape consiste à coder la fonction `DrawModel` qui permet d'appliquer la transformation $K\_{i \leftarrow c} M\_{c\leftarrow o}$ à chaque point $P\_o$ du modèle pour pouvoir les afficher dans l'image :

    def DrawModel(K, modA, matPos, ax):
        # **************************************************
        # Part 2.2: Projects 3D model modA on camera plane 
        # through matPos (4x4 homogeneous matrix) and K (camera matrix)
        # **** To be completed******************************
        # **** Use functions: Projection and TransPoint ****
    
        for p in range(modA.shape[0]):
            u1 = 0
            u2 = 0
            v1 = 0
            v2 = 0  # Comment after 2.2 completion
            ax.plot([u1, u2], [v1, v2], 'k')

On peut découper cette fonction en deux sous-étapes : 

* la transformation $\mathcal{R\_o} \rightarrow \mathcal{R\_c}$ du point $P\_o$ à l'aide de la fonction `TransPoint` qui est fournie :

        P_transformed = TransPoint(matPos, P)
        
* la projection $\mathcal{R\_c} \rightarrow \mathcal{R\_i}$ du point nouvellement obtenu $P\_c$ à l'aide de la fonction `Projection` qu'il faut compléter :

        def Projection(K, P):
            # ***************************
            # Part 2.2: Projects point P (4x1) on camera plane 
            # through K (camera matrix)
            # ******* To be completed *******
        
            u = 0
            v = 0  # Comment after 2.2 completion
            return u, v


Une fois `Projection` et `DrawModel` complétées, le lancement du programme global projette effectivement dans l'image les arêtes du modèle virtuel sélectionnées plus tôt, avec les paramètres extrinsèques définis au départ.

![Première projection du modèle dans l'image](images/first_projection.png)

> La transformation appliquée à ces points n'est visiblement pas très bonne, le modèle ne *matche* pas la boite comme on le souhaiterait. Pour pouvoir différencier une "mauvaise" estimation des paramètres extrinsèques d'une "bonne", et ainsi pouvoir proposer de manière automatique une nouvelle estimation plus proche de notre objectif, il faut déterminer un critère d'erreur caractérisant la distance à laquelle on se trouve de cet objectif optimal.

#### Etape 2 : déterminer un critère d'erreur

Le critère d'erreur sert à évaluer la justesse de notre estimation. Plus l'erreur est grande, moins nos paramètres extrinsèques sont bons. Après avoir déterminé ce critère d'erreur, on pourra l'intégrer dans une boucle d'optimisation visant à le minimiser, et donc à avoir des paramètres extrinsèques les meilleurs possibles pour notre objectif d'appariement 2D/3D.

A titre d'exemple, la figure ci-dessous illustre cette boucle d'optimisation. A l'itération 0, les paramètres sont grossiers, l'erreur est grande. En modifiant les paramètres on fera diminuer l'erreur jusqu'à atteindre, dans l'idéal, une erreur nulle et une transformation optimale pour une projection parfaite du modèle 3D dans l'image 2D.

![Optimisation des paramètres extrinsèques](images/extrinsic_optim.gif)

Dans le cadre de l'appariement 2D/3D de segments, le critère d'erreur à minimiser correspond au produit scalaire de la normale au plan d'interprétation relatif à l'appariement. En d'autres termes, l'objectif est de transformer les points du modèle de sorte que les segments sélectionnés dans l'image et ceux sélectionnés dans le modèle appartiennent au même plan exprimé dans le repère caméra $\mathcal{R\_c}$.

![Plan d'interprétation relatif à l'appariement de droites](images/interpretation_plan.png)

Comme le montre la figure ci-dessus, on peut définir le *plan d'interprétation* comme étant formé par les segments $\mathcal{l\_{i \rightarrow c}^{j,1}}$ et $\mathcal{l\_{i \rightarrow c}^{j,2}}$. Dans cette notation, $j$ correspond au nombre d'arêtes sélectionnées au lancement du programme (5 par défaut). Pour chaque arête sélectionnée $j$ et exprimée dans le repère *image* $\mathcal{R_i}$, on a donc deux segments $l^1$ et $l^2$. Le segment $l^1$ est composé des deux extrémités $P\_{i \rightarrow c}^0$ et $P\_{i \rightarrow c}^1$ ; le segment $l^2$ est composé des deux extrémités $P\_{i \rightarrow c}^1$ et $P\_{i \rightarrow c}^2$. Chacun des $P\_{i \rightarrow c}$ est un point du repère *image* $\mathcal{R\_i}$ transformé dans le repère *caméra* $\mathcal{R\_c}$. Ils sont connus : ce sont ceux qui ont été sélectionnés par *click* souris.

Une fois ces segments calculés, on peut calculer la normale au plan d'interprétation $N\_c^j$. Pour rappel :

$$N = \frac{l^1 \wedge l^2}{||l^1 \wedge l^2||}$$ 

Ensuite, pour chaque segment $j \in \[1, ..., 5\]$, la distance entre le plan lié aux segments image et les points du modèle 3D peut être calculée grâce au produit scalaire des $N\_c^j$ et des $P\_{o\rightarrow c}^j$. Si le produit scalaire est nul, les deux vecteurs sont orthogonaux et le point $P\_{o\rightarrow c}^j$ appartient bien au même plan que $P\_{i \rightarrow c}^j$. Plus le produit scalaire est grand, plus les paramètres extrinsèques s'éloignent de la bonne transformation.

On calcule ce produit sur toutes les arêtes sélectionnées et on en fait la somme au carré.

Pour résumer, le critère d'optimisation des paramètres est $\sum\_{j=1}^{2n} F^j(X)^2$, avec $F^j(X) = N^j.P\_{o\rightarrow c}^{j,1}$ et $F^{j+1}(X) = N^j.P\_{o\rightarrow c}^{j,2}$. 

{{% alert warning %}}
Ici, $X$ désigne l'ensemble des paramètres $(\alpha, \beta, \gamma, t\_x, t\_y, t\_z)$ et non une coordonnée.
{{% /alert %}}

On rappelle que chaque $P\_{o\rightarrow c} = \big[ R\_{\alpha\beta\gamma} | T \big] . P\_o$ ; la valeur de l'erreur dépend donc bien de la valeur des paramètres extrinsèques. A chaque passage dans la boucle d'optimisation, changer les poids de ces paramètres aura une influence sur le critère $F(X)$.

Dans la fonction de sélection des segments du code Python, les normales doivent être calculées et stockées dans la
 variable `normale`. Elles sont ensuite concaténées au fur et à mesure dans la matrice `App2d`.

Pour rappel, chaque normale est calculée grâce aux segments $l^1$ et $l^2$ de la figure précédente, eux-mêmes définis par leurs extrémités : les points 2D du repère *image* $\mathcal{R_i}$ transformés dans le repère *caméra* $\mathcal{R_c}$ grâce à la matrice des paramètres intrinsèques $K$ (se référer au début de l'article pour implémenter la relation entre $p_i$ et $P_c$). 

    def onclick(event):
        global iClick
        if iClick >= N:
            return True

        ix, iy = event.xdata, event.ydata
        print('x = ' + str(ix) + ', y = ' + str(iy))
        pointClickList.append([ix, iy, 1]);
        if len(pointClickList) == 2:
            # plot the line
            ax2.plot([pointClickList[0][0], pointClickList[1][0]], [pointClickList[0][1], pointClickList[1][1]],
                     color=colork[iClick])
            # show the id of the edge
            ax2.text((pointClickList[0][0] + pointClickList[1][0]) / 2,
                     (pointClickList[0][1] + pointClickList[1][1]) / 2, str(iClick), color=colork[iClick])
            iClick = iClick + 1

            p1 = np.array(pointClickList[0])
            p2 = np.array(pointClickList[1])
            # *********************************
            # Part 2.1: Normal computation
            # ******* To be completed *********

            App2d.append([0, 0, 0]);  # Comment after 2.1 completion
            # **********************************

            pointClickList[:] = [];
            fig2.canvas.draw();

        return True


La fonction `CritEval` calcule le critère. Elle prend en entrée le nombre `N` d'arêtes sélectionnées, les normales
 `App2d`, et les points du modèle `App3d_mod` transformés par la matrice des paramètres extrinsèques et exprimés dans $\mathcal{R_c}$.

    def CritEval(N, App2d, App3d_mod):
        err = 0
        for p in range(N):
            # *************************************
            # Part2.3: Compute residual error
            # ******* To be completed *******
            err = err + 0
    
        return np.sqrt(err / 2 * N)

#### Etape 3 : Estimation des paramètres par la méthode des moindres carrés ordinaires

[//]: # (A chaque étape, on cherche un incrément à appliquer à chacun des paramètres $X (\alpha, \beta, \gamma, t\_x, t\_y, t\_z)$. Pour l'exemple, on peut s'intéresser seulement au paramètre $\gamma$ de rotation autour de l'axe $Z$. La procédure peut alors être illustrée par la figure suivante : ![Incréments successifs des paramètres extrinsèques](images/increment_gamma.png) Le point de départ est exprimé dans son repère objet $\mathcal{R\_O}$. A l'itération $k=0$, la transformation effectuée est : $$\begin{bmatrix}X \\\\\\ Y \\\\\\ Z\end{bmatrix}\_{\mathcal{R\_C\_0}}} = \[R\_\gamma . R\_\beta . R\_\alpha | T\_{xyz}\]\_{k=0}\begin{bmatrix}X \\\\\\ Y \\\\\\ Z\end{bmatrix}\_{\mathcal{R\_{O}}}$$ Si l'on appelle $M\_{k=0}$ la matrice des paramètres extrinsèques $\[R\_\gamma . R\_\beta . R\_\alpha | T\_{xyz}\]\_{k=0}$, on aura à l'itération $k=1$ : $$ \begin{bmatrix}X \\\\\\ Y \\\\\\ Z\end{bmatrix}\_{\mathcal{R\_{C\_1}}} = \[R\_{\Delta\gamma} . R\_{\Delta\beta} . R\_{\Delta\alpha} | T\_{\Delta x, \Delta y, \Delta z}\]\_{k=1}. M\_{k=0}.\begin{bmatrix}X \\\\\\ Y \\\\\\ Z \end{bmatrix}\_{\mathcal{R\_{O}}}$$)

A chaque itération $k$, on cherche un jeu de paramètres $X\_{k}(\alpha, \beta, \gamma, t\_x, t\_y, t\_z)$ tel que le 
critère $F(X)$ soit égal au critère pour le jeu de paramètres précédent $X_0$ (avant mise à jour) incrémenté d'un delta pondéré par la jacobienne de la fonction.

On cherche donc à résoudre un système de la forme :

$$F(X) \approx F(X\_0) + J \Delta X$$

{{% alert note %}}
La jacobienne $J$ contient sur ses lignes les dérivées partielles de la fonction $F$ pour chaque point sélectionné et selon chacun des paramètres de $X$. Elle traduit la tendance du critère (montant/descendant) et la vitesse à laquelle il augmente ou diminue en fonction de la valeur de chacun de ses paramètres.
{{% /alert %}}

Notre objectif étant d'atteindre un critère $F(X) = 0$, on traduit le problème à résoudre par :

$$\begin{align}
  0 &= F(X\_0) + J \Delta X \\\\\\
  \llap{\Leftrightarrow \qquad} -F(X\_0) &= J \Delta X
\end{align}$$

L'intérêt de travailler par incréments successifs est d'avoir des valeurs d'incrément si petites par rapport à la dernière itération qu'on peut approximer la variation des paramètres comme étant égale à 0. Pour rappel, le critère d'erreur s'exprime de la manière suivante pour chaque segment $j$ :

$$
\begin{align}
F^{j}(X) &= N^j.P\_{o\rightarrow c}^{j} \text{ avec } P\_{o\rightarrow c}^j = \big[ R\_{\alpha\beta\gamma} | T \big] . P\_o^j\\\\\\
F^{j+1}(X) &= N^{j+1}.P\_{o\rightarrow c}^{j+1} \text{ avec } P\_{o\rightarrow c}^{j+1} = \big[ R\_{\alpha\beta\gamma} | T \big] . P\_o^{j+1}
\end{align}$$

Du fait de toujours avoir des $\Delta X \approx 0$, le calcul de la matrice jacobienne se retrouve considérablement simplifié, puisque les dérivées partielles $(\frac{\partial F^j}{\partial \alpha}, \frac{\partial F^j}{\partial \beta}, \frac{\partial F^j}{\partial \gamma}, \frac{\partial F^j}{\partial t\_x}, \frac{\partial F^j}{\partial t\_y}, \frac{\partial F^j}{\partial t\_z})$ sont les mêmes à chaque itération.

Le détail de la dérivation est donné pour le premier paramètre $\alpha$, les suivants sont éventuellement à démontrer :

$$\begin{align}
    \frac{\partial F^j}{\partial \alpha} &= N^j . [R\_\gamma . R\_\beta . \frac{\partial R\_\alpha}{\partial \alpha} | T] . P\_o^j\\\\\\
\end{align}$$

{{% alert note %}}
$R\_\gamma$ et $R\_\beta$ disparaissent de la dérivation car pour $\gamma \approx 0$ et $\beta \approx 0$, on a :

$$
R_{\gamma \approx 0} = \begin{bmatrix} 
\cos 0 & -\sin 0 & 0\\\\\\ 
\sin 0 & \cos 0 & 0\\\\\\ 
0 & 0 & 1 \end{bmatrix} = \begin{bmatrix} 
1 & 0 & 0\\\\\\ 
0 & 1 & 0\\\\\\ 
0 & 0 & 1 \end{bmatrix} = I_3
$$

$$
R_{\beta \approx 0} = \begin{bmatrix} 
\cos 0 & 0 & -\sin 0\\\\\\
0 & 1 & 0\\\\\\
\sin 0 & 0 & \cos 0 \end{bmatrix} = \begin{bmatrix} 
1 & 0 & 0\\\\\\ 
0 & 1 & 0\\\\\\ 
0 & 0 & 1 \end{bmatrix} = I_3
$$

$T$ disparaît puisque $t_x$, $t_y$, $t_z \approx 0$.

**Rappel de règles de dérivation :** $(\text{constante } a)' \rightarrow 0 \text{, } (\sin)' \rightarrow \cos \text{, } (\cos)' \rightarrow \sin$.
{{% /alert %}}

$$\begin{align}
    \frac{\partial F^j}{\partial \alpha} &= N^j . \[I_3 . I_3 . \frac{\partial R\_\alpha}{\partial \alpha} | 0\] . 
    P\_o^j\\\\\\
    &= N^j . \frac{\partial \begin{bmatrix}1 & 0 & 0\\\\\\ 0 & \cos (\alpha \approx 0) & -\sin (\alpha \approx 0)\\\\\\ 0 & \sin (\alpha \approx 0) & \cos (\alpha \approx 0) \end{bmatrix}}{\partial \alpha} . \begin{bmatrix}X^j\\\\\\ Y^j\\\\\\ Z^j\end{bmatrix}\_o\\\\\\
    &= N^j . \begin{bmatrix}0 & 0 & 0\\\\\\ 0 & \sin (\alpha \approx 0) & -\cos (\alpha \approx 0)\\\\\\ 0 & \cos (\alpha \approx 0) & \sin (\alpha \approx 0) \end{bmatrix} . \begin{bmatrix}X^j\\\\\\ Y^j\\\\\\ Z^j\end{bmatrix}\_o\\\\\\
    &= N^j . \begin{bmatrix}0 & 0 & 0\\\\\\ 0 & 0 & -1\\\\\\ 0 & 1 & 0 \end{bmatrix} . \begin{bmatrix}X^j\\\\\\ Y^j\\\\\\ Z^j\end{bmatrix}\_o\\\\\\
    &= N^j . \begin{bmatrix}0\\\\\\ -Z^j\\\\\\ Y^j\end{bmatrix}\_o\\\\\\
\end{align}$$

Le raisonnement est le même pour $\frac{\partial F^j}{\partial \beta}, \frac{\partial F^j}{\partial \gamma}, \frac{\partial F^j}{\partial t\_x}, \frac{\partial F^j}{\partial t\_y}, \frac{\partial F^j}{\partial t\_z}$ et on obtient :

$$
\frac{\partial F^j}{\partial \beta} = N^j . \begin{bmatrix}Z^j\\\\\\ 0\\\\\\ -X^j\end{bmatrix}\_o \text{, }
\frac{\partial F^j}{\partial \gamma} = N^j . \begin{bmatrix}-Y^j\\\\\\ X^j\\\\\\ 0\end{bmatrix}\_o
$$
$$
\frac{\partial F^j}{\partial t\_x} = N\_x^j \text{, }
\frac{\partial F^j}{\partial t\_y} = N\_y^j \text{, }
\frac{\partial F^j}{\partial t\_z} = N\_z^j
$$

Chacune de ces dérivées partielles est à implémenter dans la fonction `GlobalDerivative` :

    def GlobalDerivative(vectN, X, Y, Z):
        dyda = np.zeros((6))
        # **************************************
        # Part 2.4: Compute partial derivatives (see §1.3)
        # ******* To be completed *******
        dyda[0] = 0
        dyda[1] = 0
        dyda[2] = 0
        dyda[3] = 0
        dyda[4] = 0
        dyda[5] = 0
    
        # ********************************************************************
        y0 = vectN[0] * X + vectN[1] * Y + vectN[2] * Z
        return dyda, y0


On peut ainsi formaliser le problème comme étant :

$$
F = J \Delta X \text{ avec } F = \begin{bmatrix}-F^1(X\_0) \\\\\\ \vdots \\\\\\ -F^{2n}(X\_0)\end{bmatrix}\_{2n\times 1} 
$$
$$
\text{ et } J = \begin{bmatrix}\frac{\partial F^1}{\partial \alpha} & \frac{\partial F^1}{\partial \beta} & \frac{\partial F^1}{\partial \gamma} & \frac{\partial F^1}{\partial t\_x} & \frac{\partial F^1}{\partial t\_y} & \frac{\partial F^1}{\partial t\_z}\\\\\\ \vdots & \vdots & \vdots & \vdots & \vdots & \vdots \\\\\\ \frac{\partial F^{2n}}{\partial \alpha} & \frac{\partial F^{2n}}{\partial \beta} & \frac{\partial F^{2n}}{\partial \gamma} & \frac{\partial F^{2n}}{\partial t\_x} & \frac{\partial F^{2n}}{\partial t\_y} & \frac{\partial F^{2n}}{\partial t\_z}\end{bmatrix}\_{6\times 2n}
$$

{{% alert note %}}
$2n$ est le nombre de points sélectionnés, $n$ est le nombre d'arêtes (une arête = deux extrémités).
{{% /alert %}}


$F$ est connue, $J$ est connue, il ne reste plus qu'à estimer $\Delta X$ de sorte que l'égalité $F = J \Delta X$ soit
 "la plus vraie possible". Pour cela, on souhaite minimiser la distance entre les deux côtés de l'égalité :

$$
\begin{align}
\min_{\Delta X} ||F - J\Delta X||^2 & \\\\\\
\llap{\Leftrightarrow \qquad} \frac{\partial ||F - J\Delta X||^2}{\partial \Delta X} &= 0
\end{align}
$$

{{% alert note %}}
En effet, si la dérivée de la fonction à minimiser est 0, alors la courbe de la fonction a bien atteint un
 minimum.
{{% /alert %}}

En développant $(F - J \Delta X)^2$, on arrive à :

$$
\begin{align}
(F - J \Delta X)^2 & = (F - J \Delta X)^T(F - J \Delta X)\\\\\\
 &= (F^T - \Delta X^T J^T)(F - J \Delta X)\\\\\\
 &= F^TF - F^TJ\Delta X - \Delta X^T J^T F + \Delta X^T J^T J \Delta X
\end{align}
$$

On montre en s'aidant des tailles de matrices que $F^TJ\Delta X = \Delta X^T J^T F$. On en déduit :
$$
\begin{align}
(F - J \Delta X)^2 & = F^TF - 2\Delta X^T J^T F + \Delta X^T J^T J \Delta X\\\\\\
\end{align}
$$

{{% alert note %}}
**Quelques règles de dérivation :**

$\frac{\partial AX}{\partial X} = A^T$, $\frac{\partial X^TA^T}{\partial X} = A^T$, $\frac{\partial X^TAX}{\partial X} = 2AX$.
{{% /alert %}}

$$
\begin{align}
\frac{\partial (F - J \Delta X)^2}{\partial \Delta X} & = -2J^T F + 2 J^T J \Delta X\\\\\\
&= -J^T F + J^T J \Delta X\\\\\\
\llap{\Leftrightarrow \qquad} J^T F &= J^T J \Delta X \\\\\\
(J^TJ)^{-1} J^T F &= \Delta X \\\\\\
\end{align}
$$

**En résumé :** 

* minimiser la distance entre $F$ et $J\Delta X$ revient à dire que $\frac{\partial (F - J \Delta X)^2}{\partial \Delta X} = 0$ 
* la solution est $\Delta X = (J^TJ)^{-1} J^T F$. 

{{% alert note %}}
La matrice $J^+ = (J^TJ)^{-1} J^T$ s'appelle la *pseudo-inverse* de $J$.
{{% /alert %}}

Dans le code Python, on peut ainsi implémenter la mise à jour des paramètres dans la boucle d'optimisation. $\Delta X$
 correspond à la variable nommée `dSoluL`. On peut ensuite passer `dSoluL` à la fonction `TransFromParam` qui renvoie une matrice des incréments de $X$ de la même forme que `matPos` (la matrice des paramètres extrinsèques).

On incrémente chacun des éléments de `matPos` en la multipliant par `dmatPos`.


    # ******************************************************************
    # Part 2.5: To be completed using TransFromParam(.) functions ******
    # dsoluL = ??
    # dmatPos = matTools.TransFromParam(dsoluL);
    # matPos = ??
    # ******************************************************************

Une fois la boucle d'optimisation opérationnelle, le lancement du programme permet de visualiser la transformation du modèle avec les paramètres optimisés :

![Transformation du modèle après estimation de la pose caméra](images/modele_projete_image_optim.png)

#### Etape 4 : projection de la pose estimée sur l'image de la caméra #2

Grâce à la matrice de passage `matPos_cl_cr` fournie dans le code Python, on peut re-projeter le modèle dans l'image
 issue de la deuxième caméra et afficher le résultat :

    # *************************************************************************
    # Part 2.6: To be completed to project the model in the second image******
    # matPos = ?
    # *************************************************************************

![Projection dans l'image de droite](images/modele_projete_image_droite.png)

## Conclusion

Cet exercice a permis de travailler :

* les changements de repère ;
* la définition d'un critère de distance entre une observation et un objectif ;
* l'optimisation de paramètres ;
* la méthode des moindres carrés ;
* le calcul matriciel et la manipulation d'élements 2D/3D en Python.
