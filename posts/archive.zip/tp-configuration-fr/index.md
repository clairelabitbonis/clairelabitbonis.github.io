+++
title = "[Perception 3D] Configuration de l'espace de travail"
subtitle = "Configuration de l'espace de travail pour les TP de perception 3D."

date = 2016-04-20T00:00:00
lastmod = 2020-11-25T00:00:00
draft = true
math = true
highlight = true
highlight_languages = ["bash"]
comments = true

# Authors. Comma separated list, e.g. `["Bob Smith", "David Jones"]`.
authors = ["Claire Labit-Bonis"]

tags = ["teaching", "perception"]
summary = "Configuration de l'espace de travail pour les TP de perception 3D."

# Featured image
# To use, add an image named `featured.jpg/png` to your project's folder. 
[image]
  # Caption (optional)
  caption = ""

  # Focal point (optional)
  # Options: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight
  focal_point = ""

  # Show image only in page previews?
  preview_only = true
+++

{{% alert note %}}
Le TP1 de perception nécessite l'installation de CloudCompare ainsi que Python3 et certaines dépendances.
Le TP2 est exclusivement en Python.
Ce *post* décrit les procédures d'installation de Miniconda3 pour la configuration d'environnements virtuels dédiés aux
 deux TPs, l'installation de CloudCompare pour le TP1 ainsi que le téléchargement de la version portable de VS Code
  pour exécuter les codes en *debug*.
{{% /alert %}}

## Arborescence des TPs
Commencez par mettre en place l'arborescence du TP1 :

```
mkdir <path/to/directory>/Perception3D 
mkdir <path/to/directory>/Perception3D/TP1_segmentation
mkdir <path/to/directory>/Perception3D/TP2_localisation
```

Téléchargez les fichiers des TP1 et 2 sur Moodle et extrayez-les dans les dossiers correspondants :

![Arborescence des TPs](images/arborescence.png "Arborescence des TPs")

## Installation des dépendances

### CloudCompare
**Sous Ubuntu**, CloudCompare s'installe *via* une simple commande `snap` (pour d'autres distributions, il peut être n
écessaire d'installer snap au préalable) :

    snap install cloudcompare

![CloudCompare](images/cloudcompare.png "CloudCompare")

Lancez CloudCompare (le logiciel principal, pas le Viewer) et ouvrez `data01.xyz` pour vérifier votre installation.

**Sous Windows**, vous pouvez télécharger l'installeur à l'adresse http://www.danielgm.net/cc/release/. Choisissez l
'installeur de la *stable release*.

### Miniconda
{{% alert warning %}}
Faites attention à bien choisir les versions pour Python 3 !
{{% /alert %}}

Miniconda propose une version allégée de Python et permet de gérer des environnements virtuels. Téléchargez et
 installez la version correspondant à votre installation, par exemple pour un Linux 64 bits :

```
cd <path/to/directory>/Perception3D
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
chmod 755 Miniconda3-latest-Linux-x86_64.sh
./Miniconda3-latest-Linux-x86_64.sh
```

Suivez les instructions de la console : appuyez sur Entrée, acceptez la licence, spécifiez le dossier d'installation
 et acceptez d'initialiser Miniconda. Pour plus de clarté, je l'ai installé dans le
 dossier du TP mais vous pouvez l'installer ailleurs si vous comptez utiliser Miniconda par ailleurs.

```
Welcome to Miniconda3 py38_4.9.2

In order to continue the installation process, please review the license
agreement.
Please, press ENTER to continue
>>> 
===================================
End User License Agreement - Anaconda Individual Edition
===================================

Copyright 2015-2020, Anaconda, Inc.
...
Do you accept the license terms? [yes|no]
[no] >>> yes

Miniconda3 will now be installed into this location:
/home/claire/miniconda3

  - Press ENTER to confirm the location
  - Press CTRL-C to abort the installation
  - Or specify a different location below

[/home/claire/miniconda3] >>> <path/to/directory>/Perception3D/miniconda3
...
Do you wish the installer to initialize Miniconda3
by running conda init? [yes|no]
[no] >>> yes
```

Ouvrez un nouveau terminal, l'environnement de base Miniconda devrait être activé. Installez les librairies
 `matplotlib`, `numpy` et `scikit-learn`.

```
    (base) claire@claire:~/Bureau/Perception3D$ conda install matplotlib numpy scikit-learn
```

**Sous Windows**, vous pouvez télécharger l'installeur de Miniconda à l'adresse https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe.

### VSCode
Téléchargez le `.tar.gz` d'installation correspondant à votre système à l'adresse https://code.visualstudio.com/download#, décompressez-le et lancez VSCode :

![Téléchargement de VSCode](images/vs_code.png "Téléchargement de VSCode")

```
tar -xvf code-stable-x64-1605051992.tar.gz
./VSCode-linux-x64/bin/code 
```

**Sous Windows**, choisissez simplement l'installeur qui vous correspond.

Dans VSCode, commencez par installer l'extension "Python" *via* le menu **View > Extensions** :

![Installation de l'extension Python](images/python_extension.png "Installation de l'extension Python")

Ouvrez ensuite la palette de commandes avec **Ctrl+Shift+P** et tapez **Python: Select Interpreter** ; cliquez
 dessus et indiquez la localisation de votre installation `Python 3.8.X 64-bit ('base':conda)` :
 
![Palette de commandes](images/vs_code_select.png "Palette de commandes")
![Sélection de l'interpréteur](images/vs_code_interpreter.png "Sélection de l'interpréteur Python")