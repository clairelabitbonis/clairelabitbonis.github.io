+++
title = "Perception 3D #1 : Segmentation de nuages de points par capteur à lumière structurée RGB-D"
subtitle = "Contrôle qualité d'objets 3D."

date = 2016-04-20T00:00:00
lastmod = 2019-02-14T00:00:00
draft = true
math = true
highlight = true
highlight_languages = "matlab"
comments = true

# Authors. Comma separated list, e.g. `["Bob Smith", "David Jones"]`.
authors = ["Claire Labit-Bonis"]

tags = ["teaching", "perception"]
summary = "Contrôle qualité d'objets 3D."

# Featured image
# To use, add an image named `featured.jpg/png` to your project's folder. 
[image]
  # Caption (optional)
  caption = ""

  # Focal point (optional)
  # Options: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight
  focal_point = ""

  # Show image only in page previews?
  preview_only = true

#TODO: implementer en PCL. Pourquoi pas intégrer RANSAC?
+++
{{% alert note %}}
Cet exercice consiste à remplir les parties manquantes des fichiers `roi.m`, `segmentation.m` et `quality_check.m`. Chaque fonction à implémenter est décrite dans la suite de cet article. 
{{% /alert %}}

L'objectif du TP est de réaliser un contrôle qualité sur des boites *i.e.* comparer des objets à un modèle de référence pour déterminer s'ils présentent des défauts ou non. La comparaison est réalisée sur le nuage de points de ces objets, acquis avec une Kinect.

Trois acquisitions Kinect sont à notre disposition :

* le nuage de points de référence d'une boite sans défaut, stocké dans `modele.mat` à l'issue de la 
partie 1 ;
* le nuage de points d'une autre boite sans défaut, stocké dans `data02.mat` ;
* le nuage de points d'une troisième boite avec défaut, stocké dans `data03.mat`.

On souhaite comparer les deux dernières acquisitions avec la première.

# **Partie 1** : Segmentation 3D de l'objet à traiter

## Etape 1 : sélection d'une région d'intérêt autour de l'objet

{{% alert note %}}
Dans le code `roi.m`, les lignes 1 à 70 consistent à stocker les acquisitions Kinect dans des vecteurs de 
points et à les afficher dans un repère 3D. Le code de l'affichage pourra être exécuté une fois pour visualiser
 la 
scène, puis commenté pour alléger le temps d'exécution du programme.
{{% /alert %}}

Les acquisitions Kinect fournies contiennent tous les points de la scène, or la seule partie qui nous intéresse est 
la boite présente en son centre.


**Sélection d'une région d'intérêt.** On se propose en premier lieu de réduire les temps de traitement du nuage
 en isolant une région rapprochée autour de l'objet, comme l'illustre la figure suivante :
  
![Zone d'intérêt à isoler](images/roi_goal.png)

  Pour cela, il est demandé de déterminer des bornes sur les trois
  axes $X$, $Y$ et $Z$ pour ne garder dans les variables `roiX`, `roiY`, `roiZ` qu'une région d'environ 50.000 points
   centrée sur l'objet.
   
   Ces bornes sont à choisir visuellement sur l'affichage du nuage de points de la scène complète, puis à
    intégrer dans le code suivant :


    %% **********************************************************************
    % Partie 1.1-1 : Selection ROI
    % ******** A decommenter et completer ******** %
    
    % j=1;
    % for i=1:size(vecX)
    %     % A ajouter les conditions pour la fonction 'if'
    %     if( vecX(i)~=0 && ...
    %         vecY(i)~=0 && ...
    %         vecZ(i)~=0)
    %     
    %         roiX(j)=vecX(i); 
    %         roiY(j)=vecY(i); 
    %         roiZ(j)=vecZ(i); 
    %         j=j+1;
    %     end
    % end
 
 L'affichage final de la région extraite donne un résultat similaire à la figure suivante :
 
   ![Région d'intérêt extraite](images/roi_extracted.png)

Il faut maintenant isoler la boite dans la région d'intérêt et se débarrasser des points appartenant au sol.

On aimerait pouvoir appliquer un seuil sur les points 3D et ne garder 
que ceux dont le $Z$ est supérieur à la profondeur correspondant au sol, mais en raison de l'angle de prise de vue de
 la Kinect le nuage de points est incliné. Les points les plus proches de la caméra dans l'image ont une profondeur 
 $Z$ plus faible que les points les plus éloignés.
 
 Une solution est alors de *remettre la scène à plat* en calculant l'angle de rotation à lui appliquer.

## Etape 2 : rotation de la scène

La méthode proposée consiste à effectuer une triangulation de Delaunay
 sur le nuage de points, calculer les normales de chaque triangle et construire l'histogramme de leur coordonnée 
 sphérique $\varphi$ pour en déduire l'angle de rotation à appliquer à la scène. 
 
 **Triangulation de Delaunay.** Dans le fichier `segmentation.m`, la partie correspondant à la 
 triangulation est à compléter en utilisant la fonction `delaunay` de MATLAB. Le résultat peut être affiché grâce à
  la fonction `trisurf`.
 
    %% **********************************************************************
    % Partie 1.1-2 : Triangulation de Delaunay
    %   On utilise la methode de Delaunay pour organiser les points en
    %   triangles, afin de recuperer les differents plans
    %   ******* A completer ******* %
    
 {{% alert warning %}}
 On souhaite obtenir des triangles et non des tétrahèdres. Consultez la [documentation de la fonction `delaunay`]
 (https://fr.mathworks.com/help/matlab/ref/delaunay.html) pour des exemples d'utilisation.
 {{% /alert %}}
 
 La fonction renvoie un tableau d'indices constitué de trois colonnes (pour les trois sommets A, B, C des triangles) 
 et d'autant de lignes qu'il y a de triangles :
 
 ![Tableau d'indice des triangles](images/triangles_delaunay.png)
 
 Pour accéder aux coordonnées $(x, y, z)$ du sommet A du premier triangle, on aurait par exemple :
 
    x = roiX(7027)
    y = roiY(7027)
    z = roiZ(7027)
    
    A_1 = [x y z]
 
 Pour récupérer les coordonnées $(X, Y, Z)$ de tous les sommets A, on peut utiliser l'écriture matricielle :
    
    A = [roiX(triangles(:, 1))` roiY(triangles(:, 1))` roiZ(triangles(:, 1))`]
 
 **Calcul des normales et conversion en coordonnées sphériques.** Comme l'illustre la figure suivante, 
 chaque 
 vecteur normal à un triangle a une orientation qui lui est propre.
 ![Normales aux triangles](images/normal_triangles.png)
  
  Récupérer l'angle $\varphi$ de chacune de ces normales en convertissant ses coordonnées cartésiennes $(x, y, z)$ en 
  coordonnées sphériques $(r, \theta, \varphi)$ revient à récupérer l'angle d'élévation des triangles. Les 
  composantes $r$ et $\theta$ ne nous sont pas utiles pour l'application.
 
 ![Angle élévation des normales aux triangles](images/angle_normal.png)
 
 Toujours dans le fichier `segmentation.m`, le calcul des normales, leur conversion en coordonnées 
 sphériques à l'aide de la fonction `cart2sph` et l'affichage de l'histogramme de la coordonnée $\varphi$ sont à 
 compléter :
 
     %% **********************************************************************
    % Partie 1.1-3 : Histogramme (elevation)
    %   ******* A completer ******* %
    % Affichage de l'histogramme
    %   ******* A completer ******* %
    

 Le vecteur unitaire normal à un triangle formé par ses sommets A, B et C est exprimé par :
 
 $$\hat{N} = \frac{AB \wedge BC}{||AB \wedge BC ||}$$
 
{{% alert note %}}
On peut utiliser les fonctions `cross` et `norm` pour le produit vectoriel et la norme.
{{% /alert %}}

**Construction de la matrice de rotation.** Grâce à l'histogramme, on peut déduire l'angle 
d'élévation du plan du sol dans le nuage de points. On peut également identifier les zones du nuage et de l'objet sur les 
 différentes barres de l'histogramme. Après déduction de l'angle de rotation à appliquer à la scène, on construit la 
 matrice de rotation associée :


    %% **********************************************************************
    % Partie 1.1-4 : Rotation de la scene pour recuperer les points a la surface
    % de l`objet
    % On recupere l`orientation des normales grace a l`histogramme
    %   ******* A completer ******* %
    % Calcul de la matrice de rotation
    %   ******* A decommenter et completer ******* %
    % a = ...;
    % R = [ . . . ;
    %       . . . ;
    %       . . .];
    %   
    % roi = [roiX;roiY;roiZ];
    % roiR = R*roi;

Une fois la rotation appliquée à la scène, l'objectif est de garder les 9.000 à 10.000 points de la partie supérieure
 de l'objet en fixant un seuil sur la coordonnée $Z$ :
    
    %% Seuillage entre les points du sol et la surface de l`objet
    %   ******* A decommenter et completer ******* %
    % s=size(roiR);
    % j=1;
    % for i=1:s(2)
    %     if (roiR(3,i) > ...)
    %         modele(:,j)=roiR(:,i);
    %         j=j+1;
    %     end
    % end
      
Les points à supprimer sont en rouge sur la figure de gauche ;
  la 
figure de droite illustre le résultat attendu.

![Scène après rotation](images/rotated_scene.png)


    

# **Partie 2** : Contrôle qualité

Après avoir nettoyé le nuage 3D de la scène pour ne récupérer que l'objet que l'on souhaite traiter, un contrôle 
qualité peut être effectué grâce à l'algorithme *Iterative Closest Point*. Le nuage traité lors de la partie 
précédente a été stocké dans le fichier `modele.mat` ; la même procédure a été effectuée sur deux autres boites 
(l'une avec un défaut, l'autre sans) et les points ont été stockées dans les fichiers `data02.mat` et `data03.mat`.
 
L'algorithme ICP est implémenté dans le fichier `icp.m` et son utilisation est détaillée dans le commentaire 
d'en-tête de la fonction. Le code de `quality_check.m` peut être complété pour exécuter et afficher les résultats 
retournés par ICP, pour `data02.mat` et `data03.mat` :

![Résultat renvoyé par l'algorithme ICP](images/icp.png)

## Conclusion

Cet exercice a permis de :

* manipuler des matrices de points 3D ;
* appliquer des transformations et changements de repères ;
* utiliser l'algorithme ICP pour le contrôle de pièces.
