+++
title = "[3D Perception] Workspace configuration"
subtitle = "Workspace configuration for 3D perception practical sessions."

date = 2016-04-20T00:00:00
lastmod = 2021-10-13T00:00:00
draft = false
math = true
highlight = true
highlight_languages = ["bash"]
comments = true

# Authors. Comma separated list, e.g. `["Bob Smith", "David Jones"]`.
authors = ["Claire Labit-Bonis"]

tags = ["teaching", "perception"]
summary = "Workspace configuration for 3D perception practical sessions."

# Featured image
# To use, add an image named `featured.jpg/png` to your project's folder. 
[image]
  # Caption (optional)
  caption = ""

  # Focal point (optional)
  # Options: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight
  focal_point = ""

  # Show image only in page previews?
  preview_only = true
+++

{{% alert note %}}
Practical session #1 requires the installation of CloudCompare as well as Python3 and some dependencies.
Practical session #2 only requires Python.
This post describes the procedures for installing Miniconda3 to set up virtual environments dedicated to both sessions, installing CloudCompare for #1 and downloading the portable version of VS Code to run the codes in debug mode.
{{% /alert %}}

## Arborescence des TPs
Start by setting up the file tree:
```
mkdir <path/to/directory>/3DPerception
mkdir <path/to/directory>/3DPerception/1_Segmentation
mkdir <path/to/directory>/3DPerception/2_Localisation
```

Download the files for #1 and #2 on Moodle and extract them into the corresponding folders:

![Practical sessions file tree](images/arborescence.png "Practical sessions file tree")

## Dependencies installation

### CloudCompare
**On Ubuntu**, CloudCompare is installed *via* a simple `snap` command (for other distributions, it may be necessary to install snap beforehand):

    snap install cloudcompare

![CloudCompare](images/cloudcompare.png "CloudCompare")

Launch CloudCompare (the main software, not the Viewer) and open `data01.xyz` to check your installation.

**On Windows**, you can download the installer at http://www.danielgm.net/cc/release/. Choose the *stable release* installer.

### Miniconda
{{% alert warning %}}
Be careful to choose the right versions for Python 3 !
{{% /alert %}}

Miniconda offers a light version of Python and allows to manage virtual environments. Download and install the version corresponding to your installation, e.g. for a 64 bits Linux :

```
cd <path/to/directory>/Perception3D
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
chmod 755 Miniconda3-latest-Linux-x86_64.sh
./Miniconda3-latest-Linux-x86_64.sh
```

Follow the console instructions: press Enter, accept the license, specify the installation folder and agree to initialize Miniconda.For clarity, I have installed it in the TP folder but you can install it somewhere else if you intend to use Miniconda elsewhere.

```
Welcome to Miniconda3 py38_4.9.2

In order to continue the installation process, please review the license
agreement.
Please, press ENTER to continue
>>> 
===================================
End User License Agreement - Anaconda Individual Edition
===================================

Copyright 2015-2020, Anaconda, Inc.
...
Do you accept the license terms? [yes|no]
[no] >>> yes

Miniconda3 will now be installed into this location:
/home/claire/miniconda3

  - Press ENTER to confirm the location
  - Press CTRL-C to abort the installation
  - Or specify a different location below

[/home/claire/miniconda3] >>> <path/to/directory>/3DPerception/miniconda3
...
Do you wish the installer to initialize Miniconda3
by running conda init? [yes|no]
[no] >>> yes
```

Open a new terminal, the Miniconda base environment should be enabled. Install `matplotlib`, `numpy` and `scikit-learn` libraries.

```
    (base) claire@claire:~/Bureau/3DPerception$ conda install matplotlib numpy scikit-learn
```

**On Windows**, you can download the Miniconda installer at https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe.

### VSCode
Download the `.tar.gz` installation file for your system at https://code.visualstudio.com/download#, unzip it and run VSCode:

![VSCode download](images/vs_code.png "VSCode download")

```
tar -xvf code-stable-x64-1605051992.tar.gz
./VSCode-linux-x64/bin/code 
```

**On Windows**, simply choose the installer that suits your configuration.

In VSCode, install the "Python" extension *via* the menu **View > Extensions** :

![Python extension install](images/python_extension.png "Python extension install")

Then open the command palette with **Ctrl+Shift+P** and type **Python: Select Interpreter**; click on it and specify the location of your installation `Python 3.8.X 64-bit ('base':conda)`:
 
![Command palette](images/vs_code_select.png "Command palette")
![Interpreter selection](images/vs_code_interpreter.png "Interpreter selection")

Ready, set, go!