+++
title = "Classification de signaux audio"
subtitle = "Etude comparative d'algorithmes de classification par apprentissage."

date = 2016-04-20T00:00:00
lastmod = 2019-03-18T00:00:00
draft = true
math = true
highlight = true
highlight_languages = "python"
comments = true

# Authors. Comma separated list, e.g. `["Bob Smith", "David Jones"]`.
authors = ["Claire Labit-Bonis"]

tags = ["teaching", "classification"]
summary = "Etude comparative d'algorithmes de classification par apprentissage."

# Featured image
# To use, add an image named `featured.jpg/png` to your project's folder. 
[image]
  # Caption (optional)
  # caption = "Image credit: [**Unsplash**](https://unsplash.com/photos/CpkOjOcXdUY)"

  # Focal point (optional)
  # Options: Smart, Center, TopLeft, Top, TopRight, Left, Right, BottomLeft, Bottom, BottomRight
  focal_point = ""

  # Show image only in page previews?
  preview_only = true
  
+++
{{% alert note %}}
Cet article donne un exemple d'utilisation de la librairie `BaseClassif3.py` pour la classification et reprend les 
éléments présentés dans la partie ***Module optionnel*** du cahier de TP.
{{% /alert %}}

## Principe des méthodes de classification par apprentissage
*Tout est dans le titre* : le principe de ces méthodes est de prédire, pour un individu donné, son appartenance à une 
classe en fonction de ce qu'il a appris de cette classe auparavant en *phase d'apprentissage* -- aussi appelée 
*entraînement*.

Par exemple, un algorithme de classification entraîné à distinguer des aliens et des predators aurait dans sa base 
d'apprentissage un ensemble d'exemples de chaque classe. Autrement dit, il apprendrait à se faire une idée générale 
de ce qu'est un *alien* (resp. *predator*) à partir de chacun des exemples qu'il aurait dans sa base de connaissance :

![Base d'apprentissage Alien versus Predator](images/train_alien.png "Alien vs. Predator training")

Une fois la représentation de chaque classe apprise, le classifieur est capable de catégoriser un nouvel alien 
(resp. predator) qu'il 
n'aurait jamais vu comme appartenant à la classe **Alien** (resp. **Predator**), grâce à la connaissance qu'il a de 
cette classe et sa 
ressemblance avec le nouvel individu :

![Base de test Alien versus Predator](images/test_alien.png "Alien vs. Predator testing")

Dans cet exemple, le nombre de classes à distinguer et leur nom sont connues : on parle d'apprentissage **supervisé**.
En apprentissage **non supervisé**, on n'étiquetterait pas les données comme étant *alien* ou *predator* ; on attendrait
 du classifieur qu'il définisse lui-même des groupes d'individus qui
 se ressemblent.

{{% alert info %}}
Le classifieur s'entraîne sur la **base d'apprentissage**, et ses performances sont évaluées sur la **base de test** 
dont il n'a jamais vu aucun exemple durant l'entraînement.
{{% /alert %}}

## Objectif du TP et création du dataset

On dispose dans le dossier `./Signaux` de 1000 fichiers audio au format `.wav`, chacun étant l'énonciation à voix haute
 de 
l'un des 
phonèmes 
suivants : **aa**, **ee**, **eh**, **eu**, **ii**, **oe**, **oh**, **oo**, **uu**, **yy**.
L'objectif est d'entrainer un classifieur à les reconnaitre.

En visualisant les signaux bruts dans le domaine temporel, on admet rapidement que la différence entre les phonèmes 
de différentes classes ne saute pas aux yeux :

![Phonème 'ee'](images/waveplot_ee.png "Phonème 'ee'")
![Phonème 'eh'](images/waveplot_eh.png "Phonème 'eh'")

En traitement de la parole, on extrait souvent des caractéristiques discriminantes de ces signaux sous la forme de
coefficients cepstraux (ou Mel Frequency Cepstral Coeficients -- 
MFCC) de manière à faciliter la différenciation entre les phonèmes. 

{{% alert info %}}
Explication détaillée des MFCCs sur le blog [Practical Cryptography](http://practicalcryptography.com/miscellaneous/machine-learning/guide-mel-frequency-cepstral-coefficients-mfccs/).
{{% / alert %}}

La librairie `BaseClassif3.py` permet de créer facilement un *dataset*, d'y appliquer certains prétraitements 
et d'entrainer un 
classifieur 
sur ses données 
d'apprentissage. Des fonctions d'évaluation des performances de classification sur la base de test et d'affichage des 
données sont 
également disponibles.

### Etape 1 : créer le *dataset* de départ

Plusieurs paramètres sont nécessaires à la construction d'un objet `BaseClassif` : 

* le nombre de paramètres de la base (dans notre cas le nombre de coefficients cepstraux -- la fonction `base.mfcc()`
 en renvoie 13 par défaut), 
* le nom des classes de référence ('aa', 'ee', 'eh', etc.), 
* le nombre de classes de travail -- qui n'est pas forcément égal au nombre de classes de référence si l'on travaille en non
  supervisé, 
* la répartition des données entre base d'apprentissage et de test. Généralement, une répartition 65%/35% est un bon 
compromis (dans notre cas on aura donc 650 fichiers en base d'apprentissage et 350 fichiers de test). 

On peut ensuite construire la base :

```python
import scipy.io.wavfile as wave
import BaseClassif3
from BaseClassif3 import NormaliseData, CalculateCovariance

Chemin="../Signaux"
Filenames=os.listdir(Chemin)
NumFiles=len(Filenames)
NomVoyelles=['aa', 'ee', 'eh', 'eu', 'ii', 'oe', 'oh', 'oo', 'uu', 'yy']
NumTest=350
NombreClasses=10
NombreParametresMFCC=13

Data0=BaseClassif3.CLASS_ClassificationData(NombreParametresMFCC, '[1] MFCC database')

for Index in NomVoyelles:
    Data0.DefineReferenceClass('Class ' + Index)
for Index in range(NombreClasses):
    Data0.DefineWorkingClass('Class {}'.format(Index))

# On génère des indices aléatoires pour les exemples de test
IndicesTest=np.random.choice(NumFiles, NumTest, replace=False)

for Index, Filename in enumerate(Filenames):
    # Le numéro de la classe est l'indice de l'élément de 'NomVoyelles' qui correspond aux deux 
    # premières lettres du nom du fichier .wav
    NumeroClasse=NomVoyelles.index(Filename[0:2])
    (f, Sig) = wave.read(os.path.join(Chemin, Filename))

    # Extraction des vecteurs MFCC
    LenFile = float(len(Sig))/f
    VecteurMFCC = base.mfcc(signal=Sig, samplerate=f, winlen=LenFile, \
        winstep=LenFile, numcep=NombreParametresMFCC)

    if Index in IndicesTest:
        Data0.AddTestingElement(VecteurMFCC, NumeroClasse)
    else:
        Data0.AddTrainingElement(VecteurMFCC, NumeroClasse)

Data0.DatabaseCompleted(NormaliseData, CalculateCovariance, Printing=True)
``` 

L'option `Printing=True` affiche les informations du *dataset* :

![Infos dataset](images/console_dataset.png)

### Etape 2 : prétraitement du *dataset*

**Analyse statistique.** L'application d'un prétraitement type *analyse en composantes principales* ou *analyse 
factorielle discriminante* a 
pour objectif de réduire le nombre de dimensions de l'espace de travail tout en perdant le moins d'information 
possible des données de départ.
Ces méthodes sont implémentées dans `BaseClassif3` et renvoient les vecteurs propres correspondant aux combinaisons 
linéaires des variables d'origine vers le nouvel espace :

```python
EigenValues, EigenVectors=Data0.FDAnalysis()  # Prétraitement AFD
```
L'analyse en composantes principales peut être appelée *via* `Data0.PCAnalysis()`.

{{% alert info %}}
Deux articles du blog [Setosa.io](http://setosa.io) "Explained Visually" donnent une explication très intéressante 
des [valeurs propres/vecteurs propres](http://setosa.io/ev/eigenvectors-and-eigenvalues/) et de 
l'[analyse en composantes principales](http://setosa.io/ev/principal-component-analysis/).
{{% /alert %}}

En guise d'exemple, la figure suivante montre les trois premiers paramètres MFCC avant projection dans un nouvel 
espace, 
puis les trois premiers paramètres de ce nouvel espace :

![Avant/après AFD](images/before_after_afd.png)

Les données d'un dataset peuvent être visualisées de la manière suivante :

```python
Data0.ReferenceClassesRepresentation2D([Index1, Index2])
Data0.ReferenceClassesRepresentation3D([Index1, Index2, Index3])
```

où `Index1/2/3` font référence à l'indice du paramètre à afficher. Si le vecteur MFCC a treize dimensions, on 
pourrait afficher chacun des paramètres allant de 0 à 12.

Pour afficher toutes les combinaisons de paramètres deux à deux, on peut par exemple écrire (si l'on a au moins 
deux dimensions 
dans notre espace) :

```python
numFig=0
for Index1 in range(NombreParametres) :
    for Index2 in range(Index1+1, NombreParametres) :
        Data1.ReferenceClassesRepresentation2D([Index1, Index2], FigNumber=numFig)
        numFig+=1
plt.show()
```

**Projection dans le nouvel espace.**
La matrice de transformation de l'espace d'origine vers 
l'espace destination de dimension $N$ est construite grâce aux $N$ premiers vecteurs propres et peut être utilisée 
pour définir un nouveau *dataset* transformé :
```python
NombreDimensionsReduites=3
MatricePassage=EigenVectors[:,:NombreDimensionsReduites]

Data1=BaseClassif3.CLASS_ClassificationData(NombreDimensionsReduites, '[2] Preprocessed database')
Data1.CopyClassesFrom(Data0)

Data1.AddVectorOfTrainingElements(
	Data0.TrainingBaseElementsProjection(MatricePassage),
	Data0.TrainingReferenceClassElementsAffectation()
)
Data1.AddVectorOfTestingElements(
	Data0.TestingBaseElementsProjection(MatricePassage),
	Data0.TestingReferenceClassElementsAffectation()
)
Data1.DatabaseCompleted(NormaliseData, CalculateCovariance, Printing=True)
```

### Etape 3 : apprentissage et classification

Quatre algorithmes de classification sont implémentés : KMeans, SVM, Perceptron et RandomForest. Chacun peut être 
entraîné avec les paramètres décrits dans la documentation `sklearn`. 

On peut ensuite facilement les utiliser :

```python
Data1.RandomForest()                            # Construction et apprentissage du classifieur
Data1.TestingBaseRandomForestClassAssignment()  # Prediction du classifieur sur chacun des exemples de la base de test
```

{{% alert info %}}
Les paramètres sont passés sous forme d'une chaine de caractères, par exemple :
```
Data1.KMeans("n_clusters={}".format(NombreClasses))
```
{{% / alert %}}

### Etape 4 : évaluation des performances

Plusieurs méthodes permettent d'évaluer les performances des classifieurs :

```python
# Affichage d'une matrice de confusion des prédictions faites sur la base d'apprentissage
Data1.PrintPerformances('Tr')
# Affichage d'une matrice de confusion des prédictions faites sur la base de test
Data1.PrintPerformances('Te')
```

![Performances de test](images/perfs_test.png)

On peut aussi utiliser les fonctions d'affichage vues précédemment pour une interprétation des résultats.

### Ce qui est attendu

Vous montrerez les résultats obtenus grâce à différents jeux de paramètres : nombre de paramètres MFCC, nombre de 
dimensions après prétraitement, type de prétraitement (il peut ne pas y en avoir), choix du classifieur, répartition 
de la base en apprentissage / classification, etc.

Vous afficherez les représentations 2D / 3D des différents paramètres et pourrez interpréter le type d'erreurs que 
vous obtiendrez d'après les matrices de confusion.

Attention, l'idée n'est pas d'avoir une montagne de figures qui montrent des résultats avec différents paramètres, mais 
bien 
d'interpréter les résultats en commentant des figures choisies pour leur pertinence.